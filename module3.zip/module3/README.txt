Group Members: John Gers and Johnathan Nguyen
Steps:
1. 	Log into bridges by using the following command:

	ssh bridges.psc.xsede.org -p 2222

	Then, enter your xsede password and do any 2-factor authentication needed.

2. 	Once logged in, make a directory called project 4 by saying:

	mkdir project4

	Then, to go into the newly made directory:

	cd project4

3. 	Load into bridges all your text files and python files into directory project4.

	For ours:
	We chose to use the filezilla application.

4.	Once you have all of your files in project4, start hadoop by saying:

	interact -N 4 -t 01:00:00
	module load hadoop
	start-hadoop.sh

	and wait.

5. 	Once it is ready, run the following command to copy the previously made
	directory into hadoop:

	hadoop fs -put /home/username/project4

	Note: replace "username" with your xsede username

6. 	Run the following commands to run the mapreduce task on the respective text file.
 
	These commands will write the output to a respective text file.

	General:

	time hadoop fs python path/mapper.py | sort -k1,1 | python path/reducer.py | sort -k 2,2n > hadoop fs -appendToFile - path/output_textfile.txt

	For ours specifically:

	time hadoop fs python /home/johngers/project4/mapper.py | sort -k 1,1| python /home/johngers/project4/reducer.py |sort -k 2,2n > /home/johngers/project4/output2.txt

	Note:
	-k Option : Unix provides the feature of sorting a table on the basis of any column number by using -k option.
	Use the -k option to sort on a certain column. For example, use “-k 2” to sort on the second column.

7. 	To display the contents of the output text file run the following command:

	hadoop fs -cat output_filename.txt


Noteworthy command-line commands:

ls - List's items in current directory
cd - Changes to a new directory
mv - Moves files between two directories
cat - Display the contents of a text file
For bridges:
cd /home/username - will take you to your root directory
nano - Invoke the nano program in order to create text files. Ex. nano filename.extension
For hadoop:
hadoop fs -ls - lists your hadoop fs contents
hadoop fs -put filename.extension or directory - move the file or directory into hadoop
hadoop fs -cat output_filename.txt - displays the contents of a text file in command line

