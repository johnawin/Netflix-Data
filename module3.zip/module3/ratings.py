# ratings.py Project #4 CS-4650
import pandas as pd

# Used to calculate the runtime
import time

movieRating = []

def readFile(input):
    data = pd.read_csv(input, names = ["user_id", "rating", "date"])
    data = data["rating"].mean()
    return data

# Start Timer for runtime
start = time.time()

for i in range (1, 17771):
	if i < 10:
		input = "/Users/johngers/desktop/module3/download/training_set/mv_000000" + str(i) + ".txt"

	elif i < 100:
		input = "/Users/johngers/desktop/module3/download/training_set/mv_00000" + str(i) + ".txt"

	elif i < 1000:
		input = "/Users/johngers/desktop/module3/download/training_set/mv_0000" + str(i) + ".txt"
	
	elif i < 10000:
		input = "/Users/johngers/desktop/module3/download/training_set/mv_000" + str(i) + ".txt"
		
	else:
		input = "/Users/johngers/desktop/module3/download/training_set/mv_00" + str(i) + ".txt"
		
	movieRating.append(readFile(input))


movies = pd.read_csv("/Users/johngers/desktop/module3/download/movie_titles.txt", names = ["movie_id", "year_released", "name"], encoding = "ISO-8859-1")
movies = movies["movie_id"]
combined = sorted(zip(movies,movieRating), key=lambda x: x[1])
print(combined)

df = pd.DataFrame(combined)

df.to_csv("/Users/johngers/desktop/movies.txt",sep='\t', index = False)

# End timer and print runtime
end = time.time()
print("\nThis program took " + "{:.7f}".format(end - start) + " seconds.")
