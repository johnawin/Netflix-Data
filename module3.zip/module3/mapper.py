# mapper.py Project #4 CS-4650
import re

def read_input(file):
    for line in file:
        # removes punctuation and makes all the characters lower case so they group properly
        line = re.sub(r'[^\w\s]','',line, re.UNICODE).lower()
        
        # split the line into words
        line = line[:-10] # Trim off the date and rating
        yield line.split()

def main(file, separator='\t'):
    # input comes from input file
    data = read_input(file)
    for words in data:
        # write the results to STDOUT (standard output);
        # what we output here will be the input for reducer.py
        for word in words:
            print( '%s%s%d' % (word, separator, 1))


if __name__ == "__main__":
	for i in range (1, 17771):
		if i < 10:
			input = "/Users/johngers/desktop/module3/download/training_set/mv_000000" + str(i) + ".txt"
			file = open(input, "r")
		elif i < 100:
			input = "/Users/johngers/desktop/module3/download/training_set/mv_00000" + str(i) + ".txt"
			file = open(input, "r")
		elif i < 1000:
			input = "/Users/johngers/desktop/module3/download/training_set/mv_0000" + str(i) + ".txt"
			file = open(input, "r")
		elif i < 10000:
			input = "/Users/johngers/desktop/module3/download/training_set/mv_000" + str(i) + ".txt"
			file = open(input, "r")
		else:
			input = "/Users/johngers/desktop/module3/download/training_set/mv_00" + str(i) + ".txt"
			file = open(input, "r")
            
		main(file)

